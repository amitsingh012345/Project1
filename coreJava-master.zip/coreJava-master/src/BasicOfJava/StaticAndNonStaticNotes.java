package BasicOfJava;

public class StaticAndNonStaticNotes {

	/**
Static Members of class are accessed by class Name, Since static members are class
Non Static members of class are accessed by object. Non Static members are object members
	 */
}
