package BasicOfJava;

public class Person {
	
	String name;
	String department;

}
