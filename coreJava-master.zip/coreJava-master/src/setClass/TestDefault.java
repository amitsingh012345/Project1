package setClass;

public class TestDefault {
	
	public static void main(String[] args) {
		Person1234 obj = new Person1234(20, "test");
		
		System.out.println(obj.getAge());
	}

}
