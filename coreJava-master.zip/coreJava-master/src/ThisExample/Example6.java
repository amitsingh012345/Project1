package ThisExample;

public class Example6 {

	Example7 obj;

	Example6(Example7 obj) {
		
		Example7 obj1 = new Example7();
		this.obj = obj;
		obj.display();
	}
}
