package methodOverLoadingInjava;

public class Notes {

	/**
Method Overloading will allow us to create more than one methods with same name by changing the method arguments.
Method Overloading is called as compile time polymorphisms.
Arguments list can be different in following ways
1) Numbers of parameters to method
2) Data Type of parameters
3) Sequence Type of parameters
	 */
}
