package programs;

public class SumOfArray {

}
