package methodOverloading;

public class Overloading11 extends Overloading10{
	
	Overloading11(){
		
	}

}
