package methodOverloading;

public class Overloading8 {

	Overloading8(int i) {

	}
	
}
