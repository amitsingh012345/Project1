package methodOverloading;

public class Overloading9 extends Overloading8 {

	Overloading9(int i) {
		super(i);
	}

	public static void main(String[] args) {

	}
}
