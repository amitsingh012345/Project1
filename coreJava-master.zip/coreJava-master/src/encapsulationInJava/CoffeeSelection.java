package encapsulationInJava;

//CoffeeSelection is a simple enum providing a set of predefined values 
// for the different kinds of coffees.

public enum CoffeeSelection {
	ESPRESSO, CAPPUCCINO,FILTER_COFFEE, ;
}