package encapsulationInJava;

public interface CoffeeMachineIf {

	Coffee brewCoffee(CoffeeSelection selection) throws Exception;
}
