package typeCasting;

public class A {
	
	public void test2(){
		System.out.println("test1");
	}

}
