package inheritanceInJava;

public class ChildClass extends ParentClass{
	
	public static void main(String[] args) {
		ChildClass obj = new ChildClass();
		obj.test1();
		obj.test2();
		obj.test3();
	}

}
