package instanceOfInJava;

public class Example1 {

	public static void main(String args[]) {
		Example1 s = new Example1();
		System.out.println(s instanceof Example1);
	}
}
