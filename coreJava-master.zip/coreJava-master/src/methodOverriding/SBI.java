package methodOverriding;

public class SBI extends Bank {

	public int rateOfInterest() {
		System.out.println("rateOfInterest= 7.5%");
		return 0;
	}
}
