package methodOverriding;

public class Example2 extends Example1 {

	static void test1() {
		System.out.println("Example2");
	}

	public static void main(String[] args) {

		Example2.test1();

	}
}
