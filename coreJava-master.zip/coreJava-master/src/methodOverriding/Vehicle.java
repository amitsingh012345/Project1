package methodOverriding;

public class Vehicle {

	public void run() {
		System.out.println("runs at 80KM/H");
	}
}
