package methodOverriding;

public class Overriding1 {
	
	public void test(){
		System.out.println("This is test implementation");
	}
	
	public void test1(){
		System.out.println("This is test implementation test1");
	}

}
