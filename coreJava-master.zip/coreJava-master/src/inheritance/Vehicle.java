package inheritance;

public class Vehicle {
	
	int speed;
	
	public void speed(int speed){
		this.speed = speed;
		System.out.println("Vehicle runts at:="+speed+"KM/H");
	}
}
