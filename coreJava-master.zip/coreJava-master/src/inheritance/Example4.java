package inheritance;

public class Example4 {

	void msg() {

	}
}
