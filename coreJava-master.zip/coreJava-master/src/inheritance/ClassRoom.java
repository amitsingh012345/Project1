package inheritance;

public class ClassRoom extends College{

	public String classRoom = "10Th";
}
