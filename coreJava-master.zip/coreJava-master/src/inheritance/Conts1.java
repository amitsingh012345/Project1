package inheritance;

public class Conts1 {

	int a;

	public Conts1(int a) {
		this.a = a;
	}
}
