package inheritance;

public class Example2 extends Exaple1{

}
