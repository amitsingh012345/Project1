package wrapperClassInjava;

class Test3 {
	public static void main(String args[]) {
		int val = 99;
		int str1 = Integer.valueOf(val);
		System.out.print(str1);
		// int str = Integer.parseInt(val);
		//System.out.print(str);
	}
}