package wrapperClassInjava;

public class Test1 {
	public static void main(String args[]) {
		String s = "77";
		int str = Integer.parseInt(s);
		System.out.print(str);
		Integer str1 = Integer.valueOf(s);
		System.out.print(str1);
	}
}
