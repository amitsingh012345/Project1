package wrapperClassInjava;

public class Example2 {

	public static void main(String args[]) {
		char val = 'A';
		int str1 = Integer.valueOf(val);
		System.out.print(str1);
		//int str = Integer.parseInt(val);
		//System.out.print(str);
	}
}
