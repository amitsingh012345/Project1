package controlStatements;

public class ForLoopExample {

	public static void main(String[] args) {

		for (int i = 0; i <= 8; i++) {
			String string = "Running For Loop and count is=" + i;
			System.out.println(string);
		}
	}
}
