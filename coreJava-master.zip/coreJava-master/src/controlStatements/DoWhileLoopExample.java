package controlStatements;

public class DoWhileLoopExample {

	public static void main(String[] args) {
		int i = 0;
		do {
			i++;
			System.out.println(i);
		} while (i < 5);
		
		
		while(i<=5){
			System.out.println(i);
			i++;
		}
	}

}
