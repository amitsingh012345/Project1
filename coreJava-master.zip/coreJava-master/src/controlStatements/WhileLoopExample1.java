package controlStatements;

public class WhileLoopExample1 {
	
	public static void main(String[] args) {
		
		while(true){
			System.out.println("while loop is running in infinitive");
		}
	}
}
