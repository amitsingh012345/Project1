package constructor;

public class Example6 extends Object{

	Example6() {
		super();
	}

	public static void main(String[] args) {

	}

}
