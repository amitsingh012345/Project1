package abstractInJava;

public abstract class Example1 {

	void test1() {

	}

	abstract void test2();

}
