package abstractInJava;

public abstract class Example2 {

	int i = 80;

	public static final int j = 40;

	abstract void test1();

	public abstract void test2();

}
