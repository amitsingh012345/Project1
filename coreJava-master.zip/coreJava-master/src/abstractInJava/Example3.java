package abstractInJava;

public abstract class Example3 {

	int i;

	String name;

	public Example3(int i, String name) {
		this.i = i;
		this.name = name;
	}

	Example3() {

	}
}
