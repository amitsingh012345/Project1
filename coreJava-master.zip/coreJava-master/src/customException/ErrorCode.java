package customException;

public enum ErrorCode {
	
	INVALID_DATA,
	INVALID_STATAE,
	INVALID_CITY;

}
