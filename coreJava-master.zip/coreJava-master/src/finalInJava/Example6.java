package finalInJava;

public class Example6 {

	int id;
	String name;
	final String PAN_CARD_NUMBER="123";

	Example6(String panNumber) {
		this.PAN_CARD_NUMBER = panNumber;
	}
}
