package finalInJava;

public class Example8 {

	static final int data;
	static {
		data = 50;
	}

	public static void main(String args[]) {
		System.out.println(Example8.data);
	}
}
