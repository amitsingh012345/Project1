package exception;

public class Example2 {

	public static void main(String[] args) {
		int i = 90 / 0;
	}

}
