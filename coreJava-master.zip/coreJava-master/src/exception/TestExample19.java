package exception;

import java.io.IOException;

public class TestExample19 {
	
	static void test1() throws IOException, Exception {
		Example19.checkData(900);	
	}
	
	public static void main(String[] args) {
		Example19.checkEligibiltyProcess(90);
	}
	
	

}
