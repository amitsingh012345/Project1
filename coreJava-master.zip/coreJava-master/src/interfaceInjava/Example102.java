package interfaceInjava;

public interface Example102 {

	void test3();
}
