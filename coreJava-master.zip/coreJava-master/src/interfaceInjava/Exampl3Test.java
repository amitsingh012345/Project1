package interfaceInjava;

public class Exampl3Test implements Exampl3 {

	public static void main(String[] args) {
		Exampl3.test2();

		Exampl3Test obj = new Exampl3Test();
		obj.test1();

	}
}
