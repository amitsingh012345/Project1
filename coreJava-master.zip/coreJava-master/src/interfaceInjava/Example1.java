package interfaceInjava;

public interface Example1 {

	int i = 90;

	void test1();

}
