package stringInjava;

public class Example8 {

	public static void main(String[] args) {
		String str = "if you want to move in automation learn java";
		if (str.contains("learn java")) {
			System.out.println("I am in");
		} else
			System.out.println("Result not found");
	}
}
