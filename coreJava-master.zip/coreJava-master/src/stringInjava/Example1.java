package stringInjava;

public class Example1 {

	public static void main(String args[]) {
		String s = "Bhanu";
		s.concat(" Java");
		System.out.println(s);
	}
}
