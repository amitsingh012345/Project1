package stringInjava;

public class Example10 {

	public static void main(String[] args) {
		String s1 = "java";
		String s2 = "c";
		String s3 = "java";
		String s4 = "python";
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
		System.out.println(s1.equals(s4));
	}

}
