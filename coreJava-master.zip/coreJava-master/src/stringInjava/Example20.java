package stringInjava;

public class Example20 {

	public static void main(String[] args) {
		String s1 = String.join("-", "hello", "java", "program");
		System.out.println(s1);
	}
}
