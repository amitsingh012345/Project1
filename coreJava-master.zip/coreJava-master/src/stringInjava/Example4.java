package stringInjava;

public class Example4 {

	public static void main(String[] args) {
		String s = "Bhanupratap";
		System.out.println(s.substring(6));
		System.out.println(s.substring(0, 6));
	}
}
