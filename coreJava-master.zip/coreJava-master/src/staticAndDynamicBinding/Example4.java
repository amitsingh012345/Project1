package staticAndDynamicBinding;

public class Example4 {
	public static void test() {
		System.out.println("Example4");
	}
}
