package staticAndDynamicBinding;

public class Example2 {
	
	void eat() {
		System.out.println("animal is eating...");
	}
}
