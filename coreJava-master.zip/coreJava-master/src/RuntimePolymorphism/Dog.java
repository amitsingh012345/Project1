package RuntimePolymorphism;

public class Dog extends Animal{

	void eat() {
		System.out.println("eats bread...");
	}

}
