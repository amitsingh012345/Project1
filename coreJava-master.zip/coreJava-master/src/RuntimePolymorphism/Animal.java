package RuntimePolymorphism;

public class Animal {

	void eat() {
		System.out.println("eating...");
	}
}
