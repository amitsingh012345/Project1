package VariableDataType;

public class Example1 {

	public int a = 90;

	public String s1 = "Test";

	public double d1 = 90.80;

	public float f1 = 90.80f;

	public long l1 = 90l;

	public static int b = 80;

	public static String s2 = "Test1";
	
	public void test(){
		int a = 80;
		System.out.println(a);
	}
	
	public void test1(int a){
		System.out.println(a);
	}
}
