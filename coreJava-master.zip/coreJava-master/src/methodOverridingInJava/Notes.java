package methodOverridingInJava;

public class Notes {

	/**
Method overriding In Java

Points to Note:-
1.    Method Overriding is the the feature of java which allow us to create same method in parent 
and child class with same name and with same arguments.
2.    Method Overriding is the the ability of java which will make sure method call will happen from a 
class for which we have created the object. Not from referenced class.
3.    At compile time method call happens from reference class.
4.    At Run time method call happens from object class.
5.    Method Overriding is possible only by inheritance.
6.    Method Overriding we also call it as run time polymorphism.
7.    Method Overriding is the the feature of java which allow us to create same method 
in parent and child class with same name and with same arguments.
	 */
}
