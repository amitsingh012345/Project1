package access.modifier.test;

import accessmodifier.Example1;

public class Example3 {

	public static void main(String[] args) {

		Example1 example1 = new Example1();
		
		example1.name2();
		
		
		System.out.println(example1.s1);
	}

}
