package staticBlock;

public class Example1 {

	private static int a;

	public static void test1() {

	}

	static {
		System.out.println("this is sttaic block");
	}
}
